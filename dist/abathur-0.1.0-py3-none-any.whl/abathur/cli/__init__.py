"""CLI interface for Abathur."""

__all__ = ["app"]

from abathur.cli.main import app
