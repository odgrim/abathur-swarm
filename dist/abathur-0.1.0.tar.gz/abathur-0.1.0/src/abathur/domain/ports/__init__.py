"""Domain ports for dependency inversion."""
